    <footer>
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-md-6"></div>
                <div class="col-md-6 text-center">
                    <h6>CONTÁCTENOS</h6>
                    <p class="text-left pl-5">
                        Teléfono: (57) 1 363 48 90<br>
                        Celular: 312 362 87 62 - 310 311 70 63<br>
                        Dirección: Calle 42 sur # 8 A 89 e<br>
                        Bogotá, Colombia
                    </p>
                </div>
            </div>
        </div>
    </footer>    
    <?php wp_footer() ?>
</body>
</html>