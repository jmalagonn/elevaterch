<section class="gr-section">
    <div class="container pt-5 pb-5">
    <div class="row">
            <div class="col">
                <h2 class="text-center">
                    GALLERÍA
                </h2>
            </div>
        </div>
        <div class="row pt-4">
            <div class="col">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img src="http://elevaterchingenieria.com/wp-content/uploads/2020/10/Elevaterch-2.jpeg" alt="">
                        </div>
                        <div class="swiper-slide">
                            <img src="http://elevaterchingenieria.com/wp-content/uploads/2020/10/Elevaterch-1.jpeg" alt="">
                        </div>
                        <div class="swiper-slide">
                            <img src="http://elevaterchingenieria.com/wp-content/uploads/2020/10/Elevaterch-3.jpeg" alt="">
                        </div>
                        <div class="swiper-slide">
                            <img src="http://elevaterchingenieria.com/wp-content/uploads/2020/10/Elevaterch-6.jpeg" alt="">
                        </div>
                        <div class="swiper-slide">
                            <img src="http://elevaterchingenieria.com/wp-content/uploads/2020/10/Elevaterch-5.jpeg" alt="">
                        </div>
                        <div class="swiper-slide">
                            <img src="http://elevaterchingenieria.com/wp-content/uploads/2020/10/Elevaterch-4.jpeg" alt="">
                        </div>
                    </div>

                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </div>
</section>

