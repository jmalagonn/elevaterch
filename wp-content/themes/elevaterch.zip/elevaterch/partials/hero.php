<section class="hero-home">
    <div class="hero-home--overlay"></div>
    <div class="hero-home--content">
        <h1>ELEVATERCH</h1>
        <h3>Ingeniería de transporte vertical</h3>
    </div>
</section>