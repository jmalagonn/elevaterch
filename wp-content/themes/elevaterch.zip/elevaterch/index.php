<?php get_header() ?>
    <?php get_template_part('/partials/hero') ?>
    <?php get_template_part('/partials/about-us') ?>
    <?php get_template_part('/partials/services') ?>
    <?php get_template_part('/partials/maintenance') ?>
    <?php get_template_part('/partials/gallery') ?>
<?php get_footer() ?>